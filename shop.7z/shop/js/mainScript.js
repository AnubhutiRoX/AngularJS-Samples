var myApp = angular.module('myApp',['ngRoute']);
myApp.controller('myCtrl',function($scope,$http){
	$http.get('json/mobileList.json').then(function(resp){
		$scope.mobileList = resp.data;
	})
});
myApp.config(function($routeProvider) {
	$routeProvider.when('/books',{
		templateUrl : 'pages/books.html',
		controller : 'booksCtrl'
	});
});
