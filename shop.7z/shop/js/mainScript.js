var myApp = angular.module('myApp',[]);
myApp.controller('myCtrl',function($scope,$http){
	$http.get('json/commonItems.json').then(function(resp){
		$scope.commonItems = res.data;
	})
});