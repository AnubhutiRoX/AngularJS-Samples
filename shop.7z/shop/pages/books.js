myApp.controller('booksCtrl',function($scope){
	$scope.name = "Scarlet";
});